#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/shm.h>
#define SHMKEY 75
#define K 1024
int main()
{
    int shmid;
    char *addr1;
    printf("\n\t\treceiving--USING SHARED MEMORY\n");
    printf("\t\t`````````````````````````````````");
    shmid = shmget(SHMKEY, 128 * K, IPC_CREAT | 0777);
    addr1 = shmat(shmid, 0, 0);
    printf("\n the address is:0x%p\n", addr1);
    printf("\n the received message is:%s\n", addr1);
    return (0);
}
