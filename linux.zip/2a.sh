echo " enter first no "
read a
echo " enter second no "
read b
c= expr $a + $b