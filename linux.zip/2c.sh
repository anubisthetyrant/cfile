echo "Enter a  number: "
read n

if [ $n -eq 0 ]; then
echo "Number is zero"
elif [ $n -gt 0 ]; then
echo "Number is positivie"
else
echo "Number is negative"
fi