echo "Enter a number: "
read n
i=0
a=0
b=1
if [ $n -eq $a ]; then
echo "$a"
elif [ $n -eq $b ]; then
echo "$a $b"
else
echo $a
echo $b
n1=$(expr $n - 2)
while [ $i -lt $n1 ]
do
c=$(expr $a + $b)
echo $c
a=$b
b=$c
i=$(expr $i + 1)
done
fi