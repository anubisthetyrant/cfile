#include <iostream>
#include <sys/types.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#define _XOPEN_SOURCE 600
#include <unistd.h>

using namespace std;

int main()
{
    pid_t child;
    
    cout << "pid:" << getpid() << "patent:" << getpid() << endl;
    switch (child = fork())
    {
    case (pid_t)-1:
        perror("fork");
        break;
    case (pid_t)0:
        cout << "child created:pid:" << getpid() << "patent:" << getpid() << endl;
        exit(0);
    default:
        cout << "parent after fork pid:"
             << "child pid:" << child << endl;
    }
    return 0;
}