
n=153
num=$n
ans=0

while [ $num -gt 0 ]
do
q=$(($num % 10))
ans=$(($ans + $q * $q * $q))
num=$(expr $num / 10)
done
echo "$ans"